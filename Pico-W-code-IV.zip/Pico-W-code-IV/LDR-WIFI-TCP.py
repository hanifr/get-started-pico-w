import os
import time
import microcontroller
import board
import analogio
import wifi
import socketpool
import ipaddress
import json

# Set the TCP server address and port
TCP_SERVER = "www.txio.live"
TCP_PORT = 7554

# Get Wi-Fi details from environment variables
WIFI_SSID = os.getenv("WIFI_SSID")
WIFI_PASSWORD = os.getenv("WIFI_PASSWORD")

# ID for your device
DEVICE_ID = os.getenv("DEVICE_ID")

def connect_to_wifi():
    if not WIFI_SSID or not WIFI_PASSWORD:
        print("Wi-Fi SSID or password is not provided.")
        raise ValueError("Wi-Fi SSID or password is not provided.")

    print("Connecting to WiFi '{}' ... ".format(WIFI_SSID))
    wifi.radio.connect(WIFI_SSID, WIFI_PASSWORD)
    print("Connected!")

def ping_google():
    ipv4 = ipaddress.ip_address("8.8.4.4")
    ping_result = wifi.radio.ping(ipv4)
    print("Ping to google.com: %f ms" % (ping_result * 1000))

def send_data(luxval):
    try:
        # Connect to the TCP server
        pool = socketpool.SocketPool(wifi.radio)
        addr = pool.getaddrinfo(TCP_SERVER, TCP_PORT)[0][-1]
        s = pool.socket(pool.AF_INET, pool.SOCK_STREAM)
        s.connect(addr)

        # Prepare the data as JSON
        data = {
            "SID": DEVICE_ID,
            "luxval": round(luxval, 2),
        }
        json_data = json.dumps(data)

        # Send the JSON data to the server
        s.sendall(json_data.encode('utf-8'))

    except OSError as e:
        print("Error:", e)
    finally:
        # Close the socket in a finally block to ensure it happens even if an exception occurs
        if s:
            s.close()

ldr = analogio.AnalogIn(board.GP26) 
R = 10000  # ohm resistance value

def get_voltage(raw):
    return (raw * 3.3) / 65536

def rtolux(rawval):
    vout = get_voltage(rawval)
    RLDR = (vout * R) / (3.3 - vout)
    lux = 500 / (RLDR / 1000)  # Conversion resistance to lumen
    return lux

def main():
    try:
        connect_to_wifi()
        ping_google()

        while True:
            try:
                # Create a new LDR object in each iteration to get updated readings
                raw = ldr.value

                volts = get_voltage(raw)
                luxval = rtolux(raw)
                print("raw = {:5d} volts = {:.2f} light = {:.2f}".format(raw, volts, luxval))

                # Send data to the TCP server as JSON
                send_data(luxval)

                # Wait for 5 seconds before sending data again
                time.sleep(5.0)

            except RuntimeError as error:
                print(error.args[0])
                time.sleep(2.0)
                continue
            except Exception as error:
                print("Error:", error)
                raise error

    except Exception as e:
        print("An unexpected error occurred:", e)

    # finally:
    #     # Ensure Wi-Fi is disconnected
    #     wifi.radio.disconnect()

if __name__ == "__main__":
    main()
