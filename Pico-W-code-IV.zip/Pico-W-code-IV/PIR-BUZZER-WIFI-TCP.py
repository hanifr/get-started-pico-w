"""
Example for Pi Pico W. PIR Sensor Module

Additional Library:
    -simpleio.mpy
"""

import os
import time
import board
import digitalio
import microcontroller

import wifi
import socketpool
import ipaddress
import json
import simpleio

# Set the TCP server address and port
TCP_SERVER = "www.txio.live"
TCP_PORT = 7554

# Get Wi-Fi details from environment variables
WIFI_SSID = os.getenv("WIFI_SSID")
WIFI_PASSWORD = os.getenv("WIFI_PASSWORD")

# ID for your device
DEVICE_ID = os.getenv("DEVICE_ID")

def connect_to_wifi():
    if not WIFI_SSID or not WIFI_PASSWORD:
        print("Wi-Fi SSID or password is not provided.")
        raise ValueError("Wi-Fi SSID or password is not provided.")

    print("Connecting to WiFi '{}' ... ".format(WIFI_SSID))
    wifi.radio.connect(WIFI_SSID, WIFI_PASSWORD)
    print("Connected!")

def ping_google():
    ipv4 = ipaddress.ip_address("8.8.4.4")
    ping_result = wifi.radio.ping(ipv4)
    print("Ping to google.com: %f ms" % (ping_result * 1000))

def send_data(state):
    try:
        # Connect to the TCP server
        pool = socketpool.SocketPool(wifi.radio)
        addr = pool.getaddrinfo(TCP_SERVER, TCP_PORT)[0][-1]
        s = pool.socket(pool.AF_INET, pool.SOCK_STREAM)
        s.connect(addr)

        # Prepare the data as JSON
        data = {
            "SID": DEVICE_ID,
            "state": state,
        }
        json_data = json.dumps(data)

        # Send the JSON data to the server
        s.sendall(json_data.encode('utf-8'))

    except OSError as e:
        print("Error:", e)
    finally:
        # Close the socket in a finally block to ensure it happens even if an exception occurs
        if s:
            s.close()

# Define pin connected to the piezo buzzer.
BUZZER_PIN = board.GP18

pir = digitalio.DigitalInOut(board.GP7)
pir.direction = digitalio.Direction.INPUT

def simpletone():
    for i in range(5):
        simpleio.tone(BUZZER_PIN, 261, duration=0.1)
        simpleio.tone(BUZZER_PIN, 392, duration=0.15)

def offtone():
    simpleio.tone(BUZZER_PIN, 0)

def autonomous_pir_buzzer():
    try:
        raw = pir.value

        if pir.value:
            simpletone()
        else:
            offtone()

        print("raw = {:5d}".format(raw))

        # Send data to the TCP server as JSON
        send_data(raw)

    except RuntimeError as error:
        print(error.args[0])
    except Exception as error:
        print("Error:", error)

def main():
    try:
        connect_to_wifi()
        ping_google()

        # Create a new PIR object outside the loop to get updated readings
        while True:
            autonomous_pir_buzzer()

            # Wait for 5 seconds before sending data again
            time.sleep(5.0)

    except Exception as e:
        print("An unexpected error occurred:", e)

if __name__ == "__main__":
    main()
