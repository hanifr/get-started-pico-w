# boot.py for `hx_sgp30` module
import storage

storage.remount("/", False)
